# Student App (AppsGeyser-ready)

This package contains a small student management demo app (Arabic/English).
Files:
- index.html : main app (login, students, search, link code)
- attendance.html : attendance page (toggle present/absent stored in localStorage)

Usage:
- Upload the folder to GitHub Pages or any static hosting.
- Use the published URL (e.g. https://username.github.io/repo/) in AppsGeyser Website App.